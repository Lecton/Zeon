/** Automatically generated file. DO NOT MODIFY */
package com.activitytut;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}